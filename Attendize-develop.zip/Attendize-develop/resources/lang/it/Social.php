<?php

return [
    'pinterest' => 'Pinterest',
    'email' => 'E-mail',
    'facebook' => 'Facebook',
    'linkedin' => 'LinkedIn',
    'share_buttons_to_show' => 'Pulsanti di condivisione da mostrare',
    'social_settings' => 'Impostazioni Social',
    'social_share_text' => 'Testo per la condivisione Social',
    'social_share_text_help' => 'Questo è il testo predefinito che sarà mostrato quando un utente condivide il vostro evento sui social network',
    'twitter' => 'Twitter',
    'whatsapp' => 'WhatsApp',
];