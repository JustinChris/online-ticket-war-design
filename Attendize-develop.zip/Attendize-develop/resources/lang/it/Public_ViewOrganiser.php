<?php

return [
    'information' => 'Informazioni',
    'tickets' => 'Biglietti',
    'no_events' => 'non ci sono :panel_title da visualizzare.',
    'organiser_dashboard' => 'Dashboard Organizzatore ',
    'past_events' => 'Eventi passati',
    'upcoming_events' => 'Prossimi eventi',
];