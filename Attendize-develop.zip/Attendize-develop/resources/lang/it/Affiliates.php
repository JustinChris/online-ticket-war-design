<?php

return [
    'affiliate_name' => 'Nome dell\'Affiliato',
    'affiliate_tracking' => 'Tracking dell\'Affiliato',
    'affiliate_tracking_text' => 'Tenere traccia di chi sta generando vendite per il tuo evento è estremamente facile. Crea semplicemente un link di riferimento utilizzando la casella in basso e condividi il link con i tuoi affiliati / promotori di eventi.',
    'last_referral' => 'Ultimo Riferimento',
    'no_affiliate_referrals_yet' => 'Non ci sono ancora referenze di affiliati',
    'sales_volume_generated' => 'Volume delle vendite generato',
    'ticket_sales_generated' => 'Vendita di biglietti generata',
    'visits_generated' => 'Visite generate',
];