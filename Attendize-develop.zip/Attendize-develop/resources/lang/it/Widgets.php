<?php

return [
    'embed_preview' => 'Anteprima Embed',
    'event_widgets' => 'Widget Evento',
    'html_embed_code' => 'HTML Embed Code',
    'instructions' => 'Istruzioni',
    'instructions_text' => 'Copia e incolla l\'HTML fornito nel tuo sito Web, ovunque desideri che venga mostrato il widget.',
];