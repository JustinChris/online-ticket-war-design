<?php

return [
    'this_event_has_started' => 'Questo evento è iniziato. ',
    'create_tickets' => 'Crea biglietti',
    'edit_event_page_design' => 'Modifica il Design della Pagina Evento',
    'edit_organiser_fees' => 'Modifica le Commissioni di servizio',
    'event_page_visits' => 'Visite alla Pagina Evento',
    'event_url' => 'URL Evento',
    'event_views' => 'Visite Evento',
    'generate_affiliate_link' => 'Genera link di affiliazione',
    'orders' => 'Ordini',
    'quick_links' => 'Link veloci',
    'registrations_by_ticket' => 'Iscrizioni tramite Biglietto',
    'sales_volume' => 'Volume delle vendite',
    'share_event' => 'Condividi l\'evento',
    'this_event_is_on_now' => 'Questo evento è in corso',
    'ticket_sales_volume' => 'Volume di vendita biglietti',
    'tickets_sold' => 'Biglietti venduti',
    'website_embed_code' => 'Codice Embed',
];