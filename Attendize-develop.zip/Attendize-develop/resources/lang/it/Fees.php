<?php

return [
    'service_fee_fixed_price' => 'Commissione di servizio a prezzo fisso',
    'service_fee_fixed_price_help' => 'per esempio: inserire <b>1.25</b> <b>:cur1.25</b>',
    'service_fee_fixed_price_placeholder' => '0.00',
    'organiser_fees' => 'Commissione di servizio dell\'Organizzatore',
    'organiser_fees_text' => 'Queste sono commissioni opzionali che è possibile includere nel costo di ogni biglietto. Questa commissione apparirà nella fattura del compratore come <b> Costo Aggiuntivo </b>',
    'service_fee_percentage' => 'Percentuale commissione di servizio',
    'service_fee_percentage_help' => 'per esempio: inserisci <b>3.5</b> <b>3,5%</b>',
    'service_fee_percentage_placeholder' => '0.00',
];