<?php

return [
    'account_settings' => 'Impostazioni dell\'account',
    'create_organiser' => 'Crea Organizzatore',
    'feedback_bug_report' => 'Feedback / Bug Report',
    'my_profile' => 'Il mio profilo',
    'sign_out' => 'Logout',
];