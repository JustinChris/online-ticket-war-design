<?php

return [
    'question_delete' => 'Elimina domanda',
    'add_question' => 'Aggiungi domanda',
    'answers' => 'Risposte',
    'event_surveys' => 'Questionari evento',
    'export_answers' => 'Esporta risposte',
    'num_responses' => '# Risposte',
    'question_delete_title' => 'Tutte le risposte verranno eliminate. Se si desidera mantenere le risposte dei partecipanti, è possibile disattivare la domanda.',
    'question_title' => 'Titolo domanda',
    'required' => 'Obbligatorio',
    'status' => 'Stato',
    'tickets_list' => 'Biglietti: :list',
];