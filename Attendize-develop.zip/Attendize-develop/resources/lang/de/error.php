<?php

return [
    'back_soon' => 'Wir sind bald wieder da!',
    'back_soon_description'     => 'Wir verbessern gerade unsere Webseite.',

];
