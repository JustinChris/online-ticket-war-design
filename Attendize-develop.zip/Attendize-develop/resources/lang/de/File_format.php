<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 08:29:24 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Attendees.blade.php
  'Excel_xls' => 'Excel (XLS)',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Attendees.blade.php
  'Excel_xlsx' => 'Excel (XLSX)',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Attendees.blade.php
  'csv' => 'CSV',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Attendees.blade.php
  'html' => 'HTML',
);