<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/18 16:23:42 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Partials\\SurveyBlankSlate.blade.php
  'create_question' => 'Create Question',
  //==================================== Translations ====================================//
  'Q' => 'Q',
  'add_another_option' => 'Add Another Option',
  'answer' => 'Answer',
  'attendee_details' => 'Attendee Details',
  'make_this_a_required_question' => 'Make this a required option',
  'no_answers' => 'Sorry, there are no answers to this question yet.',
  'no_questions_yet' => 'No Questions Yet',
  'no_questions_yet_text' => 'Here you can add questions which attendees will be asked to answer during the check-out process.',
  'question' => 'Question',
  'question_options' => 'Question Options',
  'question_placeholder' => 'e.g. Please enter your full address?',
  'question_type' => 'Question Type',
  'require_this_question_for_ticket(s)' => 'Require this question for ticket(s)',
);