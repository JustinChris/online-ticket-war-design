<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Danke, dass Sie sich bei Attendize regestriert haben',
  'contact_organiser' => 'Du kannst :organiser_name gleich hier <a href="mailto::organiser_email">:organiser_email</a> kontaktieren oder dieser E-Mail antworten.',
  'invite_user' => ':name hat Ihnen einen :app account erstellt.',
  'message_received_from_organiser' => 'Du hast eine Nachricht von :organiser_name zu der Veranstaltung :event_title bekommen.',
  'message_regarding_event' => 'Die Nachricht betrifft: :event',
  'organiser_copy' => '[Kopie für den Veranstalter]',
  'refund_from_name' => 'Sie haben eine Rückerstattung von :name erhalten',
  'your_ticket_cancelled' => 'Ihr Ticket wurde storniert',
  'your_ticket_for_event' => 'Ihr Ticket für die Veranstaltung :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' =>
  array (

  ),
);
