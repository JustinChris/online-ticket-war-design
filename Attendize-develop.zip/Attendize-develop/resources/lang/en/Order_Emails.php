<?php
return [
    'received_new_order'             => 'You have received a new order for the event',
    'order_still_awaiting_payment'   => 'Please note: This order still requires payment.',
    'manage_order'                   => 'You can manage this order at',
    'successful_order'               => 'Your order for the event <strong>:name</strong> was successful.',
    'tickets_attached'               => 'Your tickets are attached to this email. You can also view you order details and download your tickets at:',
];