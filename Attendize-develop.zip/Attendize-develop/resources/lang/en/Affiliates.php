<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:14:11 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'affiliate_name' => 'Affiliate Name',
  'affiliate_tracking' => 'Affiliate Tracking',
  'affiliate_tracking_text' => 'Keeping track of who is generating sales for your event is extremely easy. Simply create a referral link using the box below and share the link with your affiliates / event promoters.',
  'last_referral' => 'Last Referral',
  'no_affiliate_referrals_yet' => 'No Affiliate Referrals Yet',
  'sales_volume_generated' => 'Sales Volume Generated',
  'ticket_sales_generated' => 'Ticket Sales Generated',
  'visits_generated' => 'Visits Generated',
);