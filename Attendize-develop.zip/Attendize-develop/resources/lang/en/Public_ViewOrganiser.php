<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/16 08:41:39 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'information' => 'Information',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'tickets' => 'Tickets',
  //==================================== Translations ====================================//
  'no_events' => 'There are no :panel_title to display.',
  'organiser_dashboard' => 'Organiser Dashboard',
  'past_events' => 'Past events',
  'upcoming_events' => 'Upcoming events',
);