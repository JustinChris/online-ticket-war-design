<?php

return [
    'back_soon'             => 'Volveremos pronto',
    'back_soon_description' => 'Actualmente estamos realizando mejoras a nuestro sitio web.',
];
