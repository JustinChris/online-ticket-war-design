<?php
return [
    'received_new_order'             => "Vous avez reçu une nouvelle commande poour l'événement",
    'order_still_awaiting_payment'   => "Note: cette commande attend encore d'être réglée.",
    'manage_order'                   => "Vous pouvez gérer cette commande sur",
    'successful_order'               => "Votre commande pour l'événement <strong>:name</strong> a été prise en compte.",
    'tickets_attached'               => "Vos billets sont joints à ce message. Vous pouvez aussi voir les détails de votre commande et télécharger vos billets sur:",
];