<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:07:35
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'scan_another_ticket' => 'Scanner un autre ticket',
  'scanning' => 'Scan en cours',
  //==================================== Translations ====================================//
  'attendees' => 'Participants',
  'check_in' => 'Enregistrement : :event',
  'email' => 'e-mail',
  'email_address' => 'Adresse e-mail',
  'event_attendees' => 'Participants à l\'évènement',
  'first_name' => 'Prénom',
  'last_name' => 'Nom de famille',
  'name' => 'Nom',
  'search_attendees' => 'Rechercher des participants...',
  'send_invitation_n_ticket_to_attendee' => 'Envoyer invitation et ticket au participant.',
);
