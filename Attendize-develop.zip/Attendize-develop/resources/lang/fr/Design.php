<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:21:50 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'event_page_preview' => 'Page de prévisualisation de l\'événement',
  //==================================== Translations ====================================//
  'background_options' => 'Options de fond de page',
  'images_provided_by_pixabay' => 'Images fournie par <b>PixaBay.com</b>',
  'select_from_available_images' => 'Choisir parmi les images disponibles',
  'use_a_colour_for_the_background' => 'Utiliser une couleur de fond de page',
);
