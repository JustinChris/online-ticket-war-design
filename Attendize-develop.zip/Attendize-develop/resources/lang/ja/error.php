<?php

return [
    'back_soon'             => 'すぐに戻ります',
    'back_soon_description' => '私達は現在ウェブサイトを改善しています。',

];
