<?php

return array(
    'attendize_register'      => 'Attendizeに登録していただきありがとうございます',
    'contact_organiser' => ':organiser_name に連絡するには <a href="mailto::organiser_email">:organiser_email</a>、またはこのメールに返信してください。',
    'invite_user'             => ':nameがあなたを:appアカウントに追加しました。',
  'message_received_from_organiser' => ':event_title に関して :organiser_name からメッセージを受け取りました。',
    'message_regarding_event' => ':eventに関するメッセージ',
    'organiser_copy'          => '[主催者コピー]',
    'refund_from_name'        => 'あなたは:nameから払い戻しを受けました。',
    'your_ticket_cancelled'   => 'あなたのチケットはキャンセルされました',
    'your_ticket_for_event'   => 'イベント:eventのためのあなたのチケット。',
    //================================== Obsolete strings ==================================//
    'LLH:obsolete'            =>
        array(),
);
