<?php
return [
    'received_new_order'             => 'イベント',
    'order_still_awaiting_payment'   => 'ご注意：この注文にはまだ支払いが必要です。',
    'manage_order'                   => 'この注文を管理できます。',
    'successful_order'               => 'イベント<strong>:name</strong>に対するあなたの注文は成功しました。',
    'tickets_attached'               => 'あなたのチケットはこのEメールに添付されています。 また、注文の詳細を表示して、チケットをダウンロードすることもできます。',
];