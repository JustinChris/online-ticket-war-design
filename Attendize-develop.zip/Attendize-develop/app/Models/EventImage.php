<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of EventImage.
 *
 * @author Dave
 */
class EventImage extends MyBaseModel
{
    //put your code here.
}
