<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of OrderStatus.
 *
 * @author Dave
 */
class OrderStatus extends \Illuminate\Database\Eloquent\Model
{
    public $timestamps = false;
}
